# Activity3

Creating publisher and subscriber scripts for group chat <br/>

publisher.py -- publisher script <br/>
subscriber.py -- subscriber script <br/>

# Library
pip install paho-mqtt
